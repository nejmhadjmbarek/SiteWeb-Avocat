@extends('avocat.compte')



@section('content_comp')





<form class="form-inline" method="post" action ="enreg_dossier">
    <input type="hidden" name="_token" value="{{ csrf_token() }}">
    <hr>
    <div class="form-group">
        <label for="exampleInputName2">Numero</label>

        <input type="text" class="form-control" id="c1" placeholder="numero" name="num"></div>
    <hr>  <input type="hidden" name="id_camarade" id="c13">
    <input type="hidden" name="id_client" id="c11">
    <input type="hidden" name="id_opposant" id="c12">

    <fieldset>
        <legend>personnes</legend>
        <div class="form-group">
            <label for="exampleInputName2">client</label>
            <a data-toggle="modal" data-target="#myModal2" >
                <input type="text" class="form-control" id="c2"  name="client" placeholder="choisir client"readonly="readonly">&nbsp;
            </a>
                <span style="color: #0000C2" data-toggle="modal" data-target="#myModal" class="glyphicon glyphicon glyphicon-plus"></span>
               </div>
        <div class="form-group">
            <label for="exampleInputEmail2">opposant</label>
            <a data-toggle="modal" data-target="#myModal3">
                <input id="c3" type="text" class="form-control"name ="opposant" placeholder=""readonly="readonly">
            </a>
                <span style="color: #0000C2" data-toggle="modal" data-target="#myModal1" class="glyphicon glyphicon glyphicon-plus"></span>
              </div><br><br><br>
        <div class="form-group">
            <label for="exampleInputName2">avocat d'opposant</label>
            <a data-toggle="modal" data-target="#myModal4">
                <input type="text" class="form-control"id="c5" placeholder="Jane Doe"readonly="readonly">
            </a>
            <span style="color: #0000C2" data-toggle="modal" data-target="#myModal5" class="glyphicon glyphicon glyphicon-plus"></span>

        </div>
        <br/>
        <br/>

        <div class="form-group">
            <label for="exampleInputName2">nature de client</label>
            &nbsp;&nbsp;&nbsp;
            <select  name="type_client" class="form-control" id="sel1">
                <option>1dfgfdghfghf</option>
                <option>2hgfhdghdg</option>
                <option>3ghghgdh</option>
                <option>4ghgdhgh</option>
            </select>
        </div>

    </fieldset><br><br>
    <fieldset>
        <legend>tribunale</legend>

        <div class="form-group">
            <label for="exampleInputName2">tribunale</label>
            <a data-toggle="modal" data-target="#myModal6" >
                <input type="text" class="form-control" id="c6"  name ="tribunal"placeholder="choisir tribunal"readonly="readonly">
            </a>   </div>
        <div class="form-group">
            <label for="exampleInputEmail2">nature</label>
            <select name="type_affaire" width="100%" class="form-control" id="sel1">
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
            </select>

        </div><br><br><br>
        <div class="form-group">
            <label for="exampleInputName2">detail tribunale</label>
            <textarea  name ="detail_tribunal" class="form-control" rows="3"></textarea>            </div>

        <div class="form-group">
            <label for="exampleInputName2">sujet</label>
            <textarea name="sujet" class="form-control" rows="3"></textarea>
        </div>


    </fieldset>
    </hr><br><br>
    <fieldset>
        <legend>details</legend>

        <div class="form-group">
            <label for="exampleInputName2">date enregistrement</label>
            <div class="form-group">

                <div class="col-xs-12 date">
                    <div class="input-group input-append date" id="dateRangePicker">
                        <input type="text" class="form-control" name="date_affaire" />
                        <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label for="exampleInputEmail2">remarque</label>
            <textarea class="form-control" rows="3"></textarea>
        </div><br><br><br>
        <div class="form-group">
            <label for="exampleInputName2">honoraires</label>
            <input type="text" class="form-control" placeholder="saisir honoriare " name="honoriare ">
        </div>
    </fieldset>
    </hr>

    <script>
        $(document).ready(function() {
            $('#dateRangePicker')
                .datepicker({
                    format: 'yyyy-mm-dd',
                    startDate: '2010-01-01',
                    endDate: '2020/12/30'
                })
                .on('changeDate', function(e) {
                    // Revalidate the date field
                    $('#dateRangeForm').formValidation('revalidateField', 'date');
                });
            $('#dateRangeForm').formValidation({
                framework: 'bootstrap',
                icon: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    date: {
                        validators: {
                            notEmpty: {
                                message: 'The date is required'
                            },
                            date: {
                                format: 'yyyy-mm-ddY',
                                min: '2010-01-01',
                                max: '2020/12/30',
                                message: 'The date is not a valid'
                            }
                        }
                    }
                }
            });
        });
    </script>








    <button type="submit" class="btn btn-primary">Sign in</button>




</form>



<div class="modal fade" id="myModal" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
<form action="">

    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Nouveau client
                </h4>
            </div>
            <div class="modal-body">
                    <table>
                        <tr>
                            <td >
                                <label >Genre</label>
                                <select class="form-control" name="genre" required >
                                    <option value="Mr">Mr</option>
                                    <option value="Mme">Mme</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label  >Nom</label>
                                <input  required class="form-control" value="" name="nom" type="text"/>
                            </td>

                            <td style="width: 50%">
                                <label >Prénom</label>
                                <input required class="form-control" value="" name="prenom" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label >Adresee</label>
                                <input required class="form-control" name="adresse" type="text"/>
                            </td>

                        </tr>
                    </table>
                    &nbsp;
                    <table>
                        <tr>
                            <td style="width: 50%">
                                <label >Téléphone</label>
                                <input required class="form-control" name="tel" type="text"/>
                            </td>
                            <td>
                                <label >Fax</label>
                                <input class="form-control" name="fax" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label >GSM</label>
                                <input class="form-control" name="gsm" type="text"/>
                            </td>
                            <td>
                                <label >Email</label>
                                <input required class="form-control" name="email" type="email"/>
                            </td>
                        </tr>
                    </table>
                    &nbsp;
                    <table>
                        <tr>
                            <td style="width: 50%">
                                <label >NCIN</label>
                                <input class="form-control" name="ident" required type="text"/>
                            </td>
                            <td>
                                <label >Lieu</label>
                                <input class="form-control" name="lieu_ident" required type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Date</label><br/>
                                <div class="col-md-4">{!!Form::text ('jj',null,['class'=>'form-control','placeholder'=>'jj','required'])!!}</div>
                                <div class="col-md-4">{!!Form::text ('mm',null,['class'=>'form-control','placeholder'=>'mm','required'])!!}</div>
                                <div class="col-md-4">{!!Form::text ('aaaa',null,['class'=>'form-control','placeholder'=>'aaaa','required'])!!}</div>

                            </td>

                        </tr>
                    </table>



            </div>
            <div class="modal-footer">
                <center>
                    <button type="submit" class="btn btn-primary"
                            data-dismiss="modal">Enregistrer
                    </button>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->
    </form>
</div><!-- /.modal -->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <form action="">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Nouveau opposant
                </h4>
            </div>
            <div class="modal-body">

                    <table>
                        <tr>
                            <td >
                                <label >Genre</label>
                                <select class="form-control" name="genre" required >
                                    <option value="Mr">Mr</option>
                                    <option value="Mme">Mme</option>
                                </select>
                            </td>

                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label  >Nom</label>
                                <input  required class="form-control" value="" name="nom" type="text"/>
                            </td>

                            <td style="width: 50%">
                                <label >Prénom</label>
                                <input required class="form-control" value="" name="prenom" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label >Adresee</label>
                                <input required class="form-control" name="adresse" type="text"/>
                            </td>

                        </tr>
                    </table>
                    &nbsp;
                    <table>
                        <tr>
                            <td style="width: 50%">
                                <label >Téléphone</label>
                                <input required class="form-control" name="tel" type="text"/>
                            </td>
                            <td>
                                <label >Fax</label>
                                <input class="form-control" name="fax" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label >GSM</label>
                                <input class="form-control" name="gsm" type="text"/>
                            </td>
                            <td>
                                <label >Email</label>
                                <input required class="form-control" name="email" type="email"/>
                            </td>
                        </tr>
                    </table>
                    &nbsp;
                    <table>
                        <tr>
                            <td style="width: 50%">
                                <label >NCIN</label>
                                <input class="form-control" name="ident" required type="text"/>
                            </td>
                            <td>
                                <label >Lieu</label>
                                <input class="form-control" name="lieu_ident" required type="text"/>
                            </td>
                        </tr>
                        <br/><br/><br/>
                        <tr>
                            <td>
                                <label>Date</label>
                                <div class="col-xs-8 date">
                                    <div class="input-group date" id="dateRangePicker2">
                                        <input type="text" class="form-control" name="date_affaire" />
                                        <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
                                        <script type="text/javascript">
                                            $(function () {
                                                $('#datetimepicker2').datetimepicker();
                                            });
                                        </script>
                                    </div>
                                </div>
                            </td>

                        </tr>
                    </table>



            </div>
            <div class="modal-footer">
                <center>
                    <button type="submit" class="btn btn-primary"
                            data-dismiss="modal">Enregistrer
                    </button>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->
</form>
</div>
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Liste des client
                </h4>
            </div>
            <div class="modal-body">
            <table class="table">
               <thead>
              <tr>
                  <th>Nom & Prénom</th>
                  <th>Adresse</th>
                  <th>Téléphone</th>
              </tr>
               </thead>
            </table>
            </div>
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->

</div><!-- /.modal -->

<div class="modal fade" id="myModal4" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Avocats d'opposants
                </h4>
            </div>
            <div class="modal-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Nom & Prénom</th>
                        <th>Adresse</th>
                        <th>Téléphone</th>
                    </tr>
                    </thead>
                </table>
            </div>
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->

</div><!-- /.modal -->


<div class="modal fade" id="myModal3" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Liste des  opposants
                </h4>
            </div>
            <div class="modal-body">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Nom & Prénom</th>
                        <th>Adresse</th>
                        <th>Téléphone</th>
                    </tr>
                    </thead>
                </table>
            </div>
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->

</div><!-- /.modal -->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                    Nouveau Avocat
                </h4>
            </div>
            <div class="modal-body">
                <form action="">
                    <table>
                        <tr>
                            <td >
                                <label >Genre</label>
                                <select class="form-control" name="genre" required >
                                    <option value="Mr">Mr</option>
                                    <option value="Mme">Mme</option>
                                </select>
                            </td>
                            <td >
                                <label >Spécialité</label>
                                <select class="form-control" name="genre" required >
                                    <option value="Mr">Mr</option>
                                    <option value="Mme">Mme</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label  >Nom</label>
                                <input  required class="form-control" value="" name="nom" type="text"/>
                            </td>

                            <td style="width: 50%">
                                <label >Prénom</label>
                                <input required class="form-control" value="" name="prenom" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label >Adresee</label>
                                <input required class="form-control" name="adresse" type="text"/>
                            </td>

                        </tr>
                    </table>
                    &nbsp;
                    <table>
                        <tr>
                            <td style="width: 50%">
                                <label >Téléphone</label>
                                <input required class="form-control" name="tel" type="text"/>
                            </td>
                            <td>
                                <label >Fax</label>
                                <input class="form-control" name="fax" type="text"/>
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <label >GSM</label>
                                <input class="form-control" name="gsm" type="text"/>
                            </td>
                            <td>
                                <label >Email</label>
                                <input required class="form-control" name="email" type="email"/>
                            </td>
                        </tr>
                    </table>
                    &nbsp;
                    <table>
                        <textarea class="form-control" name="observation" id="" cols="30" rows="10"></textarea>
                    </table>
                </form>


            </div>
            <div class="modal-footer">
                <center>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->

</div><!-- /.modal -->
<div class="modal fade" id="myModal6" tabindex="-1" role="dialog"
     aria-labelledby="myModalLabel" aria-hidden="true">
 <form  data-toggle="modal" data-target="#myModal6" method="post">
     <input type="hidden" name="_token" value="{{ csrf_token() }}">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close"
                        data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h4 class="modal-title" id="myModalLabel">
                   Tribunale
                </h4>
            </div>
            <div class="modal-body">
                 <div >
                     <label>Type</label>
                     <select class="form-control" name="type">
                         <option value="a">dz</option>
                     </select>
                     <label>Région</label>
                     <select class="form-control" name="region">
                         <option value="d">sfs</option>
                     </select>


                 </div>
            </div>
            <div class="modal-footer">
                <center>
                    <button type="submit" class="btn btn-primary"
                           >Rechercher
                    </button>
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal">Close
                    </button>
                </center>


            </div>
        </div><!-- /.modal-content -->
    </div><!--/.modal-dialog -->
</form>
</div><!-- /.modal -->

@endsection